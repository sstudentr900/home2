 //日期
 var rightNav = $('.right-nav');
 var rightNavA = rightNav.find('a');
 var isTop=true;
 var timer=null;
 var navheight = 30;
 var scrollItems = rightNavA.map(function(){
     var item = $($(this).attr("href"));
     if (item.length) { return item; }
 });

 $(window).scroll(function(){
    //當前滾動高度
    var fromTop = $(this).scrollTop()+navheight;

    //日期顯示
    // if($('.article-top').offset().top<fromTop){
    //     rightNav.show();
    // }else{
    //     rightNav.hide();
    // }


    //日期加active
    var cur = scrollItems.map(function(){
         if ($(this).offset().top < fromTop)
             return this;
     });
    cur = cur[cur.length-1];
    var id = cur && cur.length ? cur[0].id : "";
    rightNavA.parent().removeClass('active').end().filter("[href='#"+id+"']").parent().addClass("active");

    //最後日期加active
    var $BodyHeight = $(document).height();//判斷整體網頁的高度
    var $ViewportHeight=$(window).height();//判斷所見範圍的高度
    var $ScrollTop=$(this).scrollTop();//偵測目前捲軸頂點
    if($BodyHeight==($ViewportHeight+$ScrollTop)){
        rightNavA.parent().removeClass("active").eq(-1).addClass("active");
        clearInterval(timer);
    }

    //scroll滾動停止動畫
     if(!isTop){
        clearInterval(timer);
    }
    isTop=false;
 })

rightNavA.click(function(e){
    e.preventDefault();
    var obj = $(this);
    var objHref = obj.attr('href');
            console.log($(objHref));
    var offsettop = $(objHref).offset().top - navheight;

    clearInterval(timer);
    timer = setInterval(function(){
        var scollTop=document.documentElement.scrollTop||document.body.scrollTop;
        var itarget = scollTop-offsettop;
        var ispeed = itarget<0?Math.ceil(-itarget/8):Math.floor(-itarget/8);
        if(Math.abs(scollTop-offsettop)<1){
            clearInterval(timer);
            document.documentElement.scrollTop=document.body.scrollTop = offsettop;
        }else{
            isTop=true;
            document.documentElement.scrollTop=document.body.scrollTop = scollTop+ispeed;
        }
    },50);
})

//打開進階搜尋
function filterOpen(){
       $('.filter').show();
    }
//關閉進階搜尋
function filterClose(obj){
       $(obj).parents('.filter').hide();
    }